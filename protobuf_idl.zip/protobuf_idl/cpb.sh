#!/bin/sh
file_name=$1

protoc $file_name --csharp_out=./csharp
protoc $file_name --objc_out=./objc
protoc $file_name --java_out=./java
 

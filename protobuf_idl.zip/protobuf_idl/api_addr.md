# app5.0 protobuf 接口地址
服务器地址: `10.12.2.37:98`

## 首页, 投注页面接口
* 首页接口: `/home/buy`
* 大乐透投注接口: `/dlt/buy`
* 竞彩足球投注: `/jczq/buy`
* 竞彩篮球投注: `/jclq/buy`

## 开奖公告接口
* 开奖公告首页: `/draw/drawhome`
* 大乐透开奖详细页: `/draw/getdltdrawlist?pi=1&ps=10`
* 双色球开奖详细页: `/draw/getssqdrawlist?pi=1&ps=10`
* 七星彩开奖详细页: `/draw/getqxcdrawlist`
* 七乐彩开奖详细页: `/draw/getqlcdrawlist`
* 排三开奖详细页: `/draw/getpsdrawlist`
* 排五开奖详细页: `/draw/getpwdrawlist`
* 福彩3d开奖详细页面: `/draw/getsddrawlist`
* 足彩开奖详细页面: `/draw/getzcdrawlist`
* 足彩对阵详情: `/draw/getzcmatchesbygameid?gameid=12345`
* 竞彩足球的开奖明细: `/draw/getjczqdrawdetail?gametime="201415"&gametypeid=123&gameid=1111`
* 竞彩篮球的开奖明细: `/draw/getjclqdrawdetail?gametime="201415"&gametypeid=123&gameid=1111`

## 成长体系接口
* 成长体系首页: `/czz/getuserinfoandtasks`
* 每日签到: `/czz/signup`
* 领取任务奖励: `/czz/gettaskaward?taskid=11`
* 领取排名奖励: `/czz/gerrankingaward?rankingtype=0`, 其中 **0: 每日排行, 1: 总排行**
* 获取排行版: `/czz/getranking`

## 比分直播接口
* 足球比分直播列表: `/live/getjczqlivematch`
* 足球比分直播轮训: `/live/zqliveinfo?gametype=120&ticks=0`
* 篮球比分直播列表: `/live/getjclqlivematch`
* 篮球比分直播轮训: `/live/lqliveinfo`

## 账户中心
* 登陆: `/account/login?username=111&pwd=212`
* 获取注册码: `/account/sendregsms?mobile=11111111`
* 注册提交: `/account/regbymobile?mobile=11111111&code=111&pwd=232323`
* 购彩列表: `/account/BuyRecords?type=1&pi=1&ps=3`
* 开通服务: `/account/OpenBetAccount`
* 资金明细: `/account/AccountLog?type=1&pi=1&ps=3`, type: 0 收支明细; 1 充值明细; 2 提现明细; 3 冻结明细

## 数据中心
* 足球分析接口: `/datacenter/getfootballmatchanalysis?matchid=%d`
* 足球赛事接口: `/datacenter/getfootballmatchinfo?matchid=%d`
* 足球积分接口: `/datacenter/getfootballteamranking?matchid=%d`
* 足球赔盘接口: `/datacenter/getfootballodds?matchid=%d&code=%d`

---
* 篮球分析接口: `/datacenter/getbasketballmatchanalysis?matchid=%d`
* 篮球赛事接口: `/datacenter/getbasketballmatchinfo?matchid=%d`
* 篮球积分接口:
* 篮球赔盘接口:

## 资讯中心
* 公告、分类接口: `/news/GetNews?pi=1&ps=20&type=2`, pi从1开始, ps缺省为20, **类别**(0:公告;1:3D;2:双色球;4:大乐透;5:排三排五;120:竞彩;110:北单;100:足彩;130篮球)
* 推荐接口: `/news/RecommendNews?pi=1&ps=20`, pi从1开始, ps缺省为20

## 走势图

## 心水模块
* 心水首页接口: `/wages/home?pi=2&ps=23
* 我的心水接口: `/wages/mywages?type=0&pi=2&ps=23   type(0我的心水,1我的买狗)
* 我的关注接口: `/wages/FollowUsers?pi=2&ps=23
* 热门比赛接口: `/wages/HotMatches
* 某场比赛的心水接口: `/wages/MatchWages?matchid=2323&pi=2&ps=232
* 某场比赛的评论接口: `/wages/MatchComments?matchid=2323&pi=2&ps=232
* 赚钱版接口: `/wages/ProfitRanking?type=0&leagueType=2  (type:0周，1月)  leagueType待定
* 人气接口: `/wages/FansRanking?type=0   (type:0周，1月，2 总)
* 专家接口: `/wages/ExpertWages?type=0&pi=1&ps=10&uid=111   (type:1最近，2历史)
* 我的心水接口: `/wages/mywages?type=0&pi=2&ps=23   type(0我的心水,1我的买狗)
* 关注接口: `/wages/SetAttention?uid=0   
* 取消关注接口: `/wages/CancelAttention?uid=0   
* 创建心水: `/wages/CreateWages  
* 支付心水: `/wages/PayWages 
* 心水足球比: `/wages/JczqBuy 











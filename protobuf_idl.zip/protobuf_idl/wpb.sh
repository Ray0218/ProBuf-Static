#!/bin/sh
file_name=$1

./protoc.exe $file_name --csharp_out=./csharp
./protoc.exe $file_name --objc_out=./objc
./protoc.exe $file_name --java_out=./java
 